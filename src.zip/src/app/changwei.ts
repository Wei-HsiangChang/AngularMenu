export class Changwei
{
    stunum!: number;
    name!: string;
    login!: string;
    campus!: string;
    assignTitle!: string;
}