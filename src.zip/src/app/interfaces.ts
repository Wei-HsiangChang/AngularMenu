export interface templateFood
{
    name: string;
    price: number;
    calories: number;    
}